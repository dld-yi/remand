<?php
session_start();
$link = mysqli_connect('localhost', 'root', '456789', 'bsglxt');//连接数据库
mysqli_query($link, 'set names utf8');
$id = $_POST['zhanghao'];
$name = $_POST['xingming'];
$age = $_POST['nianling'];
$class = $_POST['ti'];
$role = $_POST['role'];
$qq = $_POST['qq'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$submit = $_POST['submit'];
if($submit == '保存'){
	$sql = "select teacher_id from t_teacher where teacher_id = '$_SESSION[id]'";
	$res = mysqli_query($link,$sql);
	$num = mysqli_num_rows($res);
	$_SESSION['name'] = $name;
	if ($num == 1) {
		$sqla = "update t_teacher set name = '$name',sex = '$age',title = '$class',department = '$role',qq = '$qq',phone = '$phone',email = '$email' where teacher_id = '$_SESSION[id]'";
		$resa = mysqli_query($link,$sqla);
		if($resa != 0){
			echo("<script>alert('修改成功');</script>");
			header("Location:first_login_password.php");
		}else {
			echo("<script>alert('修改失败');window.history.back(-1);</script>");
		}
	}
}
if($submit == '取消'){
	require("student_message.php");
}
mysqli_close($link);
?>