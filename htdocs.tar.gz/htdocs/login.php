<?php
session_start();
$link = mysqli_connect('localhost','root','456789','bsglxt');//连接数据库
mysqli_query($link,'set names utf8');

@$userId = $_POST["userId"];
@$passWord = $_POST["passWord"];
if (@$_POST["Submit"] == "            登陆系统              ") {
    if (empty($_POST["userId"]) || empty($_POST["passWord"])) {
        echo "<script>alert('用户名或密码不能为空！');window.history.back(-1);</script>";
        echo "<script>history.back();</script>";
    }
    else if (@$_POST["role"] == "student") {
        $sql = "select * from t_student where student_id = '$userId' and password = '$passWord'";
        $res = mysqli_query($link, $sql);
        $num = mysqli_num_rows($res);
        if ($num != 0) {
        	while($row = mysqli_fetch_array($res)){
        		$name = $row['name'];
        		$major = $row['major'];
        	}
        	$_SESSION['name'] = $name;
        	$_SESSION['id'] = $userId;
        	$_SESSION['type'] = 'student';
        	if($major == null){
        		
        		header("Location:first_login_student_message.php");
        	}else{
	            echo "<script>alert('登录成功！')</script>";
	            header("Location:student/student_main.php");
        	}
        } else {
            echo "<script>alert('用户名或密码错误！');window.history.back(-1);</script>";
            require "index.html";
        }
    } else if (@$_POST["role"] == "teacher") {
        $sql = "select * from t_teacher where teacher_id = '$userId' and password = '$passWord'";
        $res = mysqli_query($link, $sql);
        $num = mysqli_num_rows($res);
        if ($num != 0) {
        	while($row = mysqli_fetch_array($res)){
        		$name = $row['name'];
        		$email = $row['email'];
        	}
        	$_SESSION['name'] = $name;
    		$_SESSION['id'] = $userId;
    		$_SESSION['type'] = 'teacher';
    		if($email == null){
    			header("Location:first_login_teacher_message.php");
    		}else{
	            echo "<script>alert('登录成功！')</script>";
	            header("Location:teacher/teacher_main.php");
    		}
        } else {
            echo "<script>alert('用户名或密码错误！');window.history.back(-1);</script>";
            require "index.html";
        }
    } else {
        $sql = "select * from t_administrator where admin_id = '$userId' and password = '$passWord'";
        $res = mysqli_query($link, $sql);
        $num = mysqli_num_rows($res);
        if ($num != 0) {
        	while($row = mysqli_fetch_array($res)){
        		$name = $row['name'];
        	}
        	$_SESSION['name'] = $name;
        		$_SESSION['id'] = $userId;
            echo "<script>alert('登录成功！')</script>";
            header("Location:admintor/admintor_main.php");
        } else {
            echo "<script>alert('用户名或密码错误！');window.history.back(-1);</script>";
            require "index.html";
        }
    }
}
mysqli_close($link);
