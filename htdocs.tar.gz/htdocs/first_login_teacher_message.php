<?php
session_start();
    $link = mysqli_connect('localhost', 'root', '456789', 'bsglxt');//连接数据库
                mysqli_query($link, 'set names utf8');
                $sql = "select * from t_teacher where teacher_id = '$_SESSION[id]'";
                $res = mysqli_query($link, $sql);
                $num = mysqli_num_rows($res);
                if ($num != 0) {
                    while ($row = mysqli_fetch_array($res)) {
                        $id = $row['teacher_id'];
                        $name = $row['name'];
                        $sex = $row['sex'];
                        $ti = $row['title'];
                        $yi = $row['department'];
                        $phone = $row['phone'];
                        $qq = $row['qq'];
                        $email = $row['email'];
                    }
                }

?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <title>完善信息</title>
    <style>
        #table{
            background-color: transparent;
            position: relative;
            top: 50px;
        }
        .d1{
            width: 80px;
        }
        .d2{
            width: 99%;
            height: 98%;
        }
        .submit{
        	position: relative;
        	left: 100px;
        }
        .quxiao{
        	position: relative;
        	left: 220px;
        }
    </style>
</head>
<body>
<center><h3>个人信息</h3></center>
<center>
    <form action="first_login_teacher_message_save.php" name="myform" method="post">
        <table id="table" width="50%" border="1">
            <tr>
                <td class="d1">学号：</td>
                <td><input type="text" class="d2" disabled="disabled" value="<?php echo $id; ?>" pattern="(\d){6,10}" required name="zhanghao"></td>

            </tr>
            <tr>
                <td class="d1">姓名：</td>
                <td><input type="text" class="d2" value="<?php echo $name; ?>" required name="xingming"></td>
            </tr>
            <tr>
                <td class="d1">年龄：</td>
                <td><input type="text" class="d2" value="<?php echo $sex; ?>" name="nianling" pattern="\d{2}"></td>
            </tr>
            <tr>
                <td class="d1">职称：</td>
                <td><select name="ti" id="zhicheng" class="">
                            <option value="讲师" selected>讲师</option>
                            <option value="实验师">实验师</option>
                            <option value="高级实验师">高级实验师</option>
                            <option value="副教授">副教授</option>
                            <option value="教授">教授</option>
                        </select></td>
            </tr>
            <tr>
                <td class="d1">院系：</td>
                <td> <select name="role" id="role" class="">
                            <option value="理工学部" selected>理工学部</option>
                            <option value="人文学部">人文学部</option>
                            <option value="医学部">医学部</option>
                        </select></td>
            </tr>
            <tr>
                <td class="d1">qq：</td>
                <td><input type="text" class="d2" value="<?php echo $qq; ?>" name="qq" pattern="\d{5,11}"></td>
            </tr>
            <tr>
                <td class="d1">联系电话：</td>
                <td><input type="text" class="d2" value="<?php echo $phone; ?>" required name="phone" pattern="^1(3|4|5|7|8)\d{9}$"></td>
            </tr>
            <tr>
                <td class="d1">邮箱：</td>
                <td><input type="text" class="d2" value="<?php echo $email; ?>" required name="email" pattern="^[a-zA-Z0-9_.-]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z0-9]{2,6}$"></td>
            </tr>
            <tr>
            	<td colspan="2"><input type="submit" class="submit" name="submit" value="保存">
            	<input type="submit" name="submit" class="quxiao" value="取消"></td>
            </tr>
        </table>
    </form>
</center>
</body>
</html>
<?php
	mysqli_close($link);
?>