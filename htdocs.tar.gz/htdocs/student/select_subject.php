<?php
session_start();
if ($_SESSION['name']  == null) {
	echo '<center><h3>请重新登录!</h3></center>';
	// require("../index.html");
	exit();
}
$id = $_SESSION['id'];
$link = mysqli_connect('localhost', 'root', '456789', 'bsglxt');//连接数据库
mysqli_query($link, 'set names utf8');
$sqla = "select * from t_student_subject where student_id = $id ";
$resa = mysqli_query($link,$sqla);
$num = mysqli_num_rows($resa);
?>
<!doctype html>
<html lang="zh-cn">
<head>
  <meta charset="UTF-8">
  <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>查看所有课题</title>
  <style>
  	button{
  		background-color: transparent;
            color: #0000CC;
            margin: 0px;
            padding: 0px;
            outline: none;
            border-width: 0px;
            font-size: 100%;
            margin-top: 1px;
            margin-left: 5px;
        }
        td{
        	text-align: center;
        }
        .d1{
        	margin-top: 50px;
        }
        table{
        	width: 80%;
        }
  </style>
</head>
<body>
<center>
	
		<?php
			if($num == 0){
				echo "<h2>课题选择</h2><table border= '0' cellspacing='0'><form action='' method = 'post'><tr>
			<td>编号</td><td>教师工号</td><td>姓名</td><td>课题</td><td>请选择课题</td>
		</tr>";
			$sql = "select * from t_subject where state = 1 and choose = 0 ORDER BY `teacher_id` ASC";
			$res = mysqli_query($link,$sql);
			while($row = mysqli_fetch_array($res)){
				$subjectId = $row['subject_id'];
				$teacherId = $row['teacher_id'];
				$name = $row['name'];
				$t1 = $row['department'];
				$sqla = "select * from t_teacher where teacher_id = $teacherId";
				$resa = mysqli_query($link,$sqla);
				while($rowa = mysqli_fetch_array($resa)){
					$nameb = $rowa['name'];
				}
				$sqlb = "select * from t_student where student_id = $id";
				$resb = mysqli_query($link,$sqlb);
				while($rowa = mysqli_fetch_array($resb)){
					$t2 = $rowa['department'];
				}
				if($t2 == $t1){
					echo "<tr>
					<td>$subjectId</td><td><button type='submit' name='button' formaction='select_subject_teacher.php' value='$teacherId'>$teacherId</button></td><td>$nameb</td><td><button formaction='select_subject_xiangxi.php' type='submit' value='$subjectId' name='button'>$name</button></td><td><button formaction='subject_select.php' type='submit' value='$subjectId' name='button'>选择</button></td>
					</tr>";
			
					
				}
			}echo "</form></table>";
	}else {
		$sql = "select * from t_student_subject where student_id = $id";
		$res = mysqli_query($link,$sql);
		while($row = mysqli_fetch_array($res)){
			$subjectId = $row['subject_id'];
			$state = $row['state'];
		}
		$sql = "select * from t_subject where subject_id = $subjectId";
		$res = mysqli_query($link,$sql);
		while($row = mysqli_fetch_array($res)){
			$teacherId = $row['teacher_id'];
			$namea = $row['name'];
		} 
		$sql = "select * from t_teacher where teacher_id = $teacherId";
		$res = mysqli_query($link,$sql);
		while(@$row = mysqli_fetch_array($res)){
			$name = $row['name'];
		}
		if($state == 0){
			echo "<center><h2>已选课题</h2><table class = 'd1' border= '0' cellspacing='0'><form action='' method = 'post'><tr>
			<td>编号</td><td>教师工号</td><td>姓名</td><td>课题</td><td>状态</td><td>重新选择</td>
		</tr><tr>
			<td>$subjectId</td><td><button type='submit' name='button' formaction='select_subject_teacher.php' value='$teacherId'>$teacherId</button></td><td>$name</td><td><button type='submit' name='button' formaction='select_subject_xiangxi.php' value='$subjectId'>$namea</button></td><td>未审核</td><td><button type='submit' name='button' formaction='select_subject_delete.php' value='$subjectId'>删除</button></td>
		</tr></form></table></center>";
		}elseif($state == 1){
			echo "<center><h2>已选课题</h2><table class = 'd1' border= '0' cellspacing='0'><form action='' method = 'post'><tr>
			<td>编号</td><td>教师工号</td><td>姓名</td><td>课题</td><td>状态</td><td>重新选择</td>
		</tr><tr>
			<td>$subjectId</td><td><button type='submit' name='button' formaction='select_subject_teacher.php' value='$teacherId'>$teacherId</button></td><td>$name</td><td><button type='submit' name='button' formaction='select_subject_xiangxi.php' value='$subjectId'>$namea</button></td><td>已审核</td><td>已通过不能删除</button></td>
		</tr></form></table></center>";
		}else{
			echo "<center><h2>已选课题</h2><table class = 'd1' border= '0' cellspacing='0'><form action='' method = 'post'><tr>
			<td>编号</td><td>教师工号</td><td>姓名</td><td>课题</td><td>状态</td><td>重新选择</td>
		</tr><tr>
			<td>$subjectId</td><td><button type='submit' name='button' formaction='select_subject_teacher.php' value='$teacherId'>$teacherId</button></td><td>$name</td><td><button type='submit' name='button' formaction='select_subject_xiangxi.php' value='$subjectId'>$namea</button></td><td>未通过审核</td><td><button type='submit' name='button' formaction='select_subject_delete.php' value='$subjectId'>删除</button></td>
		</tr></form></table></center>";
		}
		
	}
		?>
</center>
<p>注：若未显示课题信息，说明此教师已删除此课题，请删除后重新选择！</p>
</body>
</html>
<?php
mysqli_close($link);
?>