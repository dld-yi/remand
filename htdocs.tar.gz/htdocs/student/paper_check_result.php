<?php 
session_start();
if ($_SESSION['name']  == null) {
	echo '<center><h3>请重新登录!</h3></center>';
	// require("../index.html");
	exit();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>查看论文审阅结果</title>
<link href="../link.css" rel="stylesheet" type="text/css" />
<style type="text/css">

</style></head>
<body>
<?php
	
session_start();
$link = mysqli_connect('localhost', 'root', '456789', 'bsglxt');//连接数据库
mysqli_query($link, 'set names utf8');
$user_id = $_SESSION['id'];
 $sql = "select t_paper.state,t_paper.score,t_student.student_id,t_student.name  from t_paper,t_student where t_paper.student_id=t_student.student_id  and t_paper.student_id='$user_id'";
		   $res = mysqli_query($link,$sql);
		   if(mysqli_num_rows($res)>0)
		   {
		        echo "<h2 align=center>论文审阅结果</h2>";
 				echo "<table width='80%' align=center><tr>";
				echo "<td>序号</td>";
				echo "<td>学号</td>";
				echo "<td>姓名</td>";
				echo "<td>论文状态</td></tr>";
				$i = 0;
  			    while($row = mysqli_fetch_array($res))
   			   {
   				  echo "<tr><td>".($i+1)."、"."</td>";
				  echo "<td>".$row['student_id']."</td>";
	              echo "<td>".$row['name']."</td>";
	              echo "<td>";
	              if($row['score']==0)
	               echo $row['state']+1," 审还没有完成";
	              else if($row['score']<60)
	                     echo $row['state']+1," 审还没有通过";
	                   else if($row['state']<3)
		                        echo $row['state']," 审已通过";
		                     else
		                        echo "毕业设计已合格：",$row['score'],"分";
	              echo "</td><tr>";
	              $i ++;
               }
               echo "</table>";
		   }
		   else
		    echo "<h2 align='center'><font color='red'>论文还未上传</fonr></h2>";
 ?>
</body>
</html>
