<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <title>个人信息</title>
    <style>
        #table{
            background-color: transparent;
            position: relative;
            top: 50px;
        }
        .d1{
            width: 80px;
        }
    </style>
</head>
<body>
<center><h3>教师信息</h3></center>
<center>
    <table id="table" width="50%" border="1">
        <tr>
            <td class="d1">工号：</td>
            <td><center><?php

                $link = mysqli_connect('localhost', 'root', '456789', 'bsglxt');//连接数据库
                mysqli_query($link, 'set names utf8');
                $id = $_POST['button'];
                $sql = "select * from t_teacher where teacher_id = '$id'";
                $res = mysqli_query($link, $sql);
                $num = mysqli_num_rows($res);
                if ($num != 0) {
                    while ($row = mysqli_fetch_array($res)) {
                        $id = $row['teacher_id'];
                        $name = $row['name'];
                        $sex = $row['sex'];
                        $ti = $row['title'];
                        $de = $row['department'];
                        $phone = $row['phone'];
                        $qq = $row['qq'];
                        $email = $row['email'];
                    }
                }

                 echo $id; ?></center></td>
            
        </tr>
        <tr>
        	<td class="d1">姓名：</td>
            <td><center><?php echo $name; ?></center></td>
        	</tr>
        <tr>
            <td class="d1">年龄：</td>
            <td><center><?php echo $sex; ?></center></td>
        </tr>
        <tr>
            <td class="d1">职称：</td>
            <td><center><?php echo $ti; ?></center></td>
        </tr>
        <tr>
            <td class="d1">院系：</td>
            <td><center><?php echo $de; ?></center></td>
        </tr>
        <tr>
            <td class="d1">电话：</td>
            <td><center><?php echo $phone; ?></center></td>
        </tr>
        <tr>
            <td class="d1">qq：</td>
            <td><center><?php echo $qq; ?></center></td>
        </tr>
        <tr>
            <td class="d1">邮箱：</td>
            <td><center><?php echo $email; ?></center></td>
        </tr>
    </table>
</center>
</body>
</html>