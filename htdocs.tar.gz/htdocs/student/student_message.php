<?php session_start();
if ($_SESSION['name']  == null) {
	echo '<center><h3>请重新登录!</h3></center>';
	// require("../index.html");
	exit();
}
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <title>个人信息</title>
    <style>
        #table{
            background-color: transparent;
            position: relative;
            top: 50px;
        }
        .d1{
            width: 80px;
        }
        .bianji{
        	position: relative;
        	top: 50px;
        	left: 590px;
        	text-decoration: none;
        }
    </style>
</head>
<body>
<center><h3>个人信息</h3></center>
<a href="bianji.php" class="bianji">编辑</a>
<center>
    <table id="table" width="50%" border="1">
        <tr>
            <td class="d1">学号：</td>
            <td><center><?php

                $link = mysqli_connect('localhost', 'root', '456789', 'bsglxt');//连接数据库
                mysqli_query($link, 'set names utf8');
                $sql = "select * from t_student where student_id = '$_SESSION[id]'";
                $res = mysqli_query($link, $sql);
                $num = mysqli_num_rows($res);
                if ($num != 0) {
                    while ($row = mysqli_fetch_array($res)) {
                        $id = $row['student_id'];
                        $name = $row['name'];
                        $sex = $row['sex'];
                        $class = $row['class'];
                        $yi = $row['department'];
                        $ma = $row['major'];
                        $phone = $row['phone'];
                        $qq = $row['qq'];
                        $email = $row['email'];
                    }
                }

                 echo $id; ?></center></td>
            
        </tr>
        <tr>
        	<td class="d1">姓名：</td>
            <td><center><?php echo $name; ?></center></td>
        	</tr>
        <tr>
            <td class="d1">年龄：</td>
            <td><center><?php echo $sex; ?></center></td>
        </tr>
        <tr>
            <td class="d1">班级：</td>
            <td><center><?php echo $class; ?></center></td>
        </tr>
        <tr>
            <td class="d1">院系：</td>
            <td><center><?php echo $yi; ?></center></td>
        </tr>
        <tr>
            <td class="d1">专业：</td>
            <td><center><?php echo $ma; ?></center></td>
        </tr>
        <tr>
            <td class="d1">qq：</td>
            <td><center><?php echo $qq; ?></center></td>
        </tr>
        <tr>
            <td class="d1">联系电话：</td>
            <td><center><?php echo $phone; ?></center></td>
        </tr>
        <tr>
            <td class="d1">邮箱：</td>
            <td><center><?php echo $email; ?></center></td>
        </tr>
    </table>
</center>
</body>
</html>