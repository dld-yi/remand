<?php 
session_start();
if ($_SESSION['name']  == null) {
	echo '<center><h3>请重新登录!</h3></center>';
	// require("../index.html");
	exit();
}
?>
<!doctype html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
	    table{
	    	margin-top: 100px;
	    }
    	td{
    		text-align: center;
    	}
    	#submit{
    		margin-top: 20px;
    	}
    	img{
    		height: 18px;
    		margin-top: 3px;
    	}
    </style>
</head>
<body>
<form action="save_password.php" method="post">
	<center>
		<table border="0" cellspacing="0">
			<tr>
				<td>原密码：</td><td><input id="in1" type="password" name="ops" placeholder="请输入原密码" required=""></td>
				<td><img src="image/eye.jpg" onmousedown="fun11()" onmouseup="fun12()"></td>
			</tr>
			<tr>
				<td>新密码：</td><td><input id="in2" type="password" name="nps" maxlength="10" placeholder="请输入新密码" required=""></td><td><img src="image/eye.jpg"  onmousedown="fun21()" onmouseup="fun22()"></td>
			</tr>
			<tr>
				<td>确认密码：</td><td><input id="in3" type="password" name="nnps" placeholder="请确认新密码" required=""></td><td><img src="image/eye.jpg"  onmousedown="fun31()" onmouseup="fun32()"></td>
			</tr>
		</table>
		<input type="submit" id="submit" name="submit" value="确定">
	</center>
</form>
<script>
	function fun11() {
        document.getElementById('in1').type = 'text';
   }function fun12() {
        document.getElementById('in1').type = 'password';
    }
    function fun21() {
        document.getElementById('in2').type = 'text';
   }function fun22() {
        document.getElementById('in2').type = 'password';
    }
    function fun31() {
        document.getElementById('in3').type = 'text';
   }function fun32() {
        document.getElementById('in3').type = 'password';
    }
</script>
</body>
</html>