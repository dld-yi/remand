<?php
$link = mysqli_connect('localhost','root','456789','bsglxt');//连接数据库
mysqli_query($link,'set names utf8');
$id = $_POST['button'];
$sql = "select * from t_student_subject where subject_id = $id";
$res = mysqli_query($link,$sql);
while($row = mysqli_fetch_array($res)){
	$s_id = $row['student_id'];
}
$sql = "select * from t_paper where student_id = '$s_id'";
$res = mysqli_query($link,$sql);
@$num = mysqli_num_rows($res);
if ($num == 0) {
	 $sql = "update t_subject set choose = 0 where subject_id = '$id'";
	mysqli_query($link,$sql);
	$sql = "delete from t_student_subject where subject_id = '$id'";
	mysqli_query($link,$sql);
	echo("<script>alert('删除成功，请重新选择');window.history.back(-1);</script>");
}else {
	echo("<script>alert('你的论文已开始审核，不能再进行修改');window.history.back(-1);</script>");
}

mysqli_close($link);