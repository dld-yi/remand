<?php
session_start();
$link = mysqli_connect('localhost', 'root', '456789', 'bsglxt');//连接数据库
mysqli_query($link, 'set names utf8');
$id = $_POST['button'];
$ida = $_SESSION['id'];
$sql = "select * from t_subject where subject_id = $id";
$res = mysqli_query($link,$sql);
while($row = mysqli_fetch_array($res)){
	$choose = $row['choose'];
}
if($choose == 1){
	echo("<script>alert('你慢了一步，该课题已被选走了');window.history.back(-1);</script>");
}else{
	$sql = "update t_subject set choose = 1 where subject_id = '$id'";
	mysqli_query($link,$sql);
	$sql = "insert into t_student_subject values('$ida','$id','0')";
	$res=mysqli_query($link,$sql);
	if (!$res) {
		echo("<script>alert('修改失败');window.history.back(-1);</script>");
	}else{
		echo("<script>alert('选题成功，请等待审核');window.history.back(-1);</script>");
	}
}
mysqli_close($link);