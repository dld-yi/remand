<?php
session_start();
if ($_SESSION['name']  == null) {
	echo '<center><h3>请重新登录!</h3></center>';
	// require("../index.html");
	exit();
}
$link = mysqli_connect('localhost', 'root', '456789', 'bsglxt');//连接数据库
mysqli_query($link, 'set names utf8');
$id = $_SESSION['id'];
$sql = "select * from t_score where student_id = $id";
$res = mysqli_query($link,$sql);
$num = mysqli_num_rows($res);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<center>
	<?php
		if($num == 0){
			echo "您还未有成绩";
		}else {
			echo "<h2>查看成绩</h2>";
			echo "<table width='80%'><tr><td>学号</td><td>姓名</td><td>指导教师成绩</td><td>评阅教师成绩</td><td>答辩成绩</td><td>总分</td></tr>";
			$sqlc = "select * from t_score where student_id = '$id'";
				$resc = mysqli_query($link,$sqlc);
				while($rowc = mysqli_fetch_array($resc)){
					$ad = $rowc['adviser'];
					$py = $rowc['review'];
					$re = $rowc['reply'];
					$po = $rowc['points'];
					echo "<tr><td>$id</td><td>$_SESSION[name]</td><td>$ad</td><td>$py</td><td>$re</td><td>$po</td></tr>";
				}
				echo "</table>";
		}
		
	?>
</center>
</body>
</html>
