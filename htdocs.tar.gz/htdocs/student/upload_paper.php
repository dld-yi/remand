<?php 
session_start();
if ($_SESSION['name']  == null) {
	echo '<center><h3>请重新登录!</h3></center>';
	// require("../index.html");
	exit();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>上传毕业设计论文</title>
<style type="text/css">

</style></head>
 
<body>
<p>&nbsp;</p>
<h1 align="center">上传毕业设计论文</h1>
<form action="upload_paper.php" method="post" enctype="multipart/form-data" name="upload_document" class="STYLE2" id="upload_paper">
  <div align="center">上传文献 ：
    <input name="paper" type="file" class="STYLE2" id="paper" size="30" />
    <input name="Submit" type="submit" class="STYLE2" value="上传毕业设计论文" />
	<br />
  </div>
  <p>注：文件名(以学号命名，如："200693216.doc")</p>
</form>
<p align="center">&nbsp;</p>
 <?php //获得数据库连接
	session_start();
     $link = mysqli_connect('localhost','root','456789','bsglxt');//连接数据库
	 mysqli_query($link,'set names utf8');
	 $id = $_SESSION['id'];
	 $sql = "select * from t_paper where student_id = $id";
	 $res = mysqli_query($link,$sql);
	 $num = mysqli_num_rows($res);
	 if($num>0) 
	 {
	   while($row = mysqli_fetch_array($res)){
	   	$state = $row['state'];
	   	$score = $row['score'];
	   }
	 }
	 else 
	 {
	   $state  = 0;
	   $score = 0;
	  }
 ?>
 <?php
    @$Submit = $_POST["Submit"];
    $user_id = $_SESSION['id'];
	if($Submit=="上传毕业设计论文")
	{
	  $file_name = $_FILES['paper']['name'];  //获得文件名
	  if($state==0||$score>60)
	    $path = 'paper/'.($state+1)."-".$_FILES['paper']['name'];  //如果第一次上传，则使用名字如：1-200693216.doc
	  else
	    $path = 'paper/'.($state)."-".$_FILES['paper']['name'];  //文件在服务器端的存储路径:审核次数+文件名 如：1-200693216.doc
      $str=substr($file_name,0,9);
	  if(strncmp($str,$user_id,9)!=0)   //判断文件名格式是否正确
	  {
	    echo "<h1 align='center'>文件名格式不正确</h1>";
	  }
	  else
	  {    
          if(file_exists($path))      //判断是否已上传过该文件
	     {
	       echo "<form action='upload_paper.php' method='post'>";
		   echo "<div align='center'>";
		   echo "<h3 align='center'>已存在该文件，是否删除原有文件？</h3>";
		   echo "<input type='hidden' name='path' value='".$path."'/>";
		   echo "<input name='Submit' type='submit'value='确认删除'/>";
		   echo "<input name='Submit' type='submit'value='取消上传'/>";
		   echo "</div><form>";
		
	     }
	     else 
	    {  	  
		   if($state ==0)
			    $sql = "insert into t_paper values(null,'$user_id','$file_name','$path','0','0')";
		   else
		   {
              if($score <60)
		       $sql = "update t_paper set name = '$file_name',location='$path' where student_id='$user_id'";
		      else
		      {
		         if($state <3)
			     $sql = "update t_paper set score ='0',state ='($state+1)',name = '$file_name',location='$path' where student_id='$user_id'";
			     else
			      echo"<h1 align='center'>论文已通过，无须再上传</h1>";
			   }
			  
			}
		   if(isset($sql)&&$state<3)
		   {
		     if(move_uploaded_file($_FILES['paper']['tmp_name'],$path)&&mysqli_query($link,$sql)){ //上传文件,并记录在数据库中
	          echo("<script>alert('上传成功')</script>");
		     }
		     else{
		    	 echo("<script>alert('上传失败')</script>");
		     }
		   }
	    }
      }
	}
	if($Submit=="确认删除")
	{
	  $path = $_POST['path'];
	  if(file_exists($path))
	   unlink($path);
	   echo "<h1 align='center'>源文件已删除，请重新上传</h1>";
	}
    mysqli_close($link);
 ?>
</body>
</html>
