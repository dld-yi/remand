<?php
$link = mysqli_connect('localhost','root','456789','bsglxt');//连接数据库
mysqli_query($link,'set names utf8');
$name = ($_GET['button']);
$sql = "select * from t_message where name = '$name'";
$res = mysqli_query($link,$sql);
while ($row = mysqli_fetch_array($res)){
	$names = $row['name'];
	$content = $row['description'];
}
echo "<center>$names</center>";
echo  "<span style='display:block;text-indent:2em;'>$content</span>";
echo "</br>";
mysqli_close($link);
?>
