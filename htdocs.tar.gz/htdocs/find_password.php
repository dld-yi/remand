<?php
$link = mysqli_connect('localhost','root','456789','bsglxt');//连接数据库
mysqli_query($link,'set names utf8');

$id = $_POST['id'];
$phone = $_POST['phone'];
$time = date('Y-m-d');
if($_POST['submit']){
	$sql1 = "select * from t_password where id = $id";
	$res1 = mysqli_query($link,$sql1);
	$num = mysqli_num_rows($res1);
	if($num != 0){
		echo("<script>alert('已提交过申请');window.history.back(-1);</script>");
	}else{
		$sqla = "select student_id,phone from t_student where student_id = $id";
		$res = mysqli_query($link,$sqla);
		if(!$res){
			echo("<a href='find_password.html'>该用户未注册！去注册？</a>");
			}else {
				while($row = mysqli_fetch_array($res)){
				$ida = $row['student_id'];
				$phonea = $row['phone'];
				}
			if($id == $ida && $phone == $phonea){
				$sqlb = "insert into t_password values('$id','$time')";
				$resa = mysqli_query($link,$sqlb);
				if(!$sqlb){
				echo("<script>alert('重置请求提交失败');window.history.back(-1);</script>");
				}else{
				echo("<script>alert('重置请求已提交');</script>");
				echo "</br>";
				header("refresh:3;url=//www.dld-yi.top");
				print('请稍等...<br>三秒后自动跳转到登录页面~~~');
				}
				}else{
				echo("<script>alert('输入信息有误');window.history.back(-1);</script>");
			}
		}
	}
}



?>