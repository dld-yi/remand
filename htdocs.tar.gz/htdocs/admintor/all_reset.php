<?php
$link = mysqli_connect('localhost','root','456789','bsglxt');//连接数据库
mysqli_query($link,'set names utf8');
$sql = "select * from t_password";
$res = mysqli_query($link,$sql);
while($row = mysqli_fetch_array($res)){
	$id = $row['id'];
	$sqla = "update t_student set password = '$id' where student_id = '$id'";
	mysqli_query($link,$sqla);
}
$sqlb = "delete from t_password";
mysqli_query($link,$sqlb);
echo("<script>alert('重置成功');</script>");
mysqli_close($link);
require("reset_student.php");

?>