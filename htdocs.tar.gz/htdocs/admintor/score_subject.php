<?php
	$link = mysqli_connect('localhost', 'root', '456789', 'bsglxt');//连接数据库
	mysqli_query($link, 'set names utf8');
	$id = $_POST['button'];
	$ad = $_POST['zhidao'];
	$py = $_POST['pingyue'];
	$re = $_POST['dabian'];
	$po = $ad*0.4 + $py*0.3 + $re*0.3;
	$sql = "select * from t_score where student_id = '$id'";
	$res = mysqli_query($link,$sql);
		$sql = "update t_score set review = '$py',reply = '$re',points = '$po' where student_id = '$id'";
		mysqli_query($link,$sql);
		echo "<script>alert('录入成功');window.history.back(-1);</script>";
	mysqli_close($link);