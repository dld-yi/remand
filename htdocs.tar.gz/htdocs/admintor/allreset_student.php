<?php
session_start();
$link = mysqli_connect('localhost','root','456789','bsglxt');//连接数据库
mysqli_query($link,'set names utf8');
$password = $_POST['password'];
	$sqla = "select password from t_administrator where admin_id = $_SESSION[id]";
	$res = mysqli_query($link,$sqla);
	while($row = mysqli_fetch_array($res)){
		$pas = $row['password'];
	}
	if ($pas == $password){
		$sql = "update t_student set password = student_id";
		$res = mysqli_query($link,$sql);
		echo("<script>alert('重置成功');window.history.back(-1);</script>");
}else {
	echo("<script>alert('密码错误');window.history.back(-1);</script>");
}
mysqli_close($link);