<?php
session_start();
if ($_SESSION['name']  == null) {
	echo '<center><h3>请重新登录!</h3></center>';
	// require("../index.html");
	exit();
}
$link = mysqli_connect('localhost', 'root', '456789', 'bsglxt');//连接数据库
mysqli_query($link, 'set names utf8');
?>
<!doctype html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
    	table{
    		width: 80%;
    	}
    	button{
            background-color: transparent;
            color: #0000CC;
            margin: 0px;
            padding: 0px;
            outline: none;
            border-width: 0px;
            font-size: 100%;
            margin-top: 10px;
            margin-left: 5px;
        }
        td{
        	text-align: center;
        }
    </style>
</head>
<body>
<center>
	<h2>查看所有进度</h2>
	<form method="post" action="">
	<table border = '1' cellspacing='0'>
		<?php
			$sql = "select * from t_paper";
			$res = mysqli_query($link,$sql);
			if(mysqli_num_rows($res) == 0){
				echo "<h2>学生还未提交论文</h2>";
			}else {
				echo "<tr><td>序号</td><td>学生学号(姓名)</td><td>题目</td><td>教师工号(姓名)</td><td>状态</td></tr>";
				$i = 1;
				while($row = mysqli_fetch_array($res)){
					$studentId = $row['student_id'];
					$state = $row['state'];
					$score = $row['score'];
					$sqls = "select * from t_student where student_id = $studentId";
					$ress = mysqli_query($link,$sqls);
					while($rows = mysqli_fetch_array($ress)){
						$studentName = $rows['name'];
					}
					$sqla = "select * from t_student_subject where student_id = $studentId";
					$resa = mysqli_query($link,$sqla);
					while($rowa = mysqli_fetch_array($resa)){
						$subjectId = $rowa['subject_id'];
					}
					$sqlb = "select * from t_subject where subject_id = $subjectId";
					$resb = mysqli_query($link,$sqlb);
					while($rowb = mysqli_fetch_array($resb)){
						$teacherId = $rowb['teacher_id'];
						$subjectName = $rowb['name'];
					}
					$sqls = "select * from t_teacher where teacher_id = $teacherId";
					$ress = mysqli_query($link,$sqls);
					while($rows = mysqli_fetch_array($ress)){
						$teacherName = $rows['name'];
					}
					echo "<tr><td>$i</td><td>$studentName","(","$studentId",")","</td><td><button type='submit' name='button' formaction='check_subject_xiangxi.php' value='$subjectId'>$subjectName</button></td><td>$teacherName","(","$teacherId",")","</td>";
					if($score == 0){
						echo "<td>",$state+1,"审还未开始","</td></tr>";
					}elseif ($score < 60) {
						echo "<td>",$state+1,"审未通过","</td></tr>";
					}elseif($state<3){
						echo "<td>",$state,"审已通过","</td></tr>";
					}else{
						echo "<td>","毕业设计已合格：","$score","分</td></tr>";
					}
					$i ++ ;
				}
			}
		mysqli_close($link);
		
		?>
	</table>
	</form>
</center>
</body>
</html>