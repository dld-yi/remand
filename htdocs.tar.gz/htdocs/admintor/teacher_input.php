<?php session_start();
if ($_SESSION['name']  == null) {
	echo '<center><h3>请重新登录!</h3></center>';
	// require("../index.html");
	exit();
}
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <title>个人信息</title>
    <style>
        #table{
            background-color: transparent;
            position: relative;
            top: 50px;
        }
        .d1{
            width: 80px;
        }
        .d2{
            width: 99%;
            height: 98%;
        }
        .submit{
        	position: relative;
        	left: 100px;
        }
        .quxiao{
        	position: relative;
        	left: 220px;
        }
    </style>
</head>
<body>
<center><h3>录入教师信息</h3></center>
<center>
    <form action="teacher_input_save.php" name="myform" method="post">
        <table id="table" width="50%" border="1">
            <tr>
                <td class="d1">工号：</td>
                <td><input type="text" class="d2" pattern="(\d){6,10}" required name="zhanghao"></td>

            </tr>
            <tr>
                <td class="d1">姓名：</td>
                <td><input type="text" class="d2" required name="xingming"></td>
            </tr> 
            <tr>
                <td class="d1">可上传题目数量：</td>
                <td><input type="text" class="d2" value="5" required name="num" pattern="^[0-9]*$"></td>
            </tr>
            <tr>
            	<td colspan="2"><input type="submit" class="submit" name="submit" value="保存">
            	<input type="submit" name="submit" class="quxiao" value="取消"></td>
            </tr>
        </table>
    </form>
</center>
</body>
</html>