<?php
session_start();
if ($_SESSION['name']  == null) {
	echo '<center><h3>请重新登录!</h3></center>';
	// require("../index.html");
	exit();
}
$link = mysqli_connect('localhost', 'root', '456789', 'bsglxt');//连接数据库
mysqli_query($link, 'set names utf8');
$sql = "select * from t_score";
$res = mysqli_query($link,$sql);
$num = mysqli_num_rows($res);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <style>
    	input{
    		width: 30px;
    	}
    </style>
</head>
<body>
<center>
	<?php
		if($num == 0){
			echo "还未录入成绩";
		}else {
			echo "<h2>查看成绩</h2>";
			echo "<table width='80%'><tr><td>学号</td><td>姓名</td><td>指导教师成绩</td><td>评阅教师成绩</td><td>答辩成绩</td><td>总分</td><td>上传</td></tr>";
			while($row = mysqli_fetch_array($res)){
				$id = $row['student_id'];
				$sqlc = "select * from t_score where student_id = '$id'";
				$resc = mysqli_query($link,$sqlc);
				while($rowc = mysqli_fetch_array($resc)){
					$ad = $rowc['adviser'];
					$py = $rowc['review'];
					$re = $rowc['reply'];
					$po = $rowc['points'];
					$sqlm = "select * from t_student where student_id = '$id'";
					$resm = mysqli_query($link,$sqlm);
					while($rowm = mysqli_fetch_array($resm)){
						$studentName = $rowm['name'];
					}
					if($po == 0){
					echo "<form action='' method='post'><tr><td>$id</td><td>$studentName</td><td><input type='text' name='zhidao' maxlength='3' value='$ad'></td><td><input type='text' name='pingyue' maxlength='3'></td><td><input type='text' name='dabian' maxlength='3'></td><td>$po</td><td><button formaction='score_subject.php' type='submit' value='$id' name='button'>上传</button></td></tr></form>";
					}else{
						echo "<form action='' method='post'><tr><td>$id</td><td>$studentName</td><td>$ad</td><td>$py</td><td>$re</td><td>$po</td><td><button formaction='score_change.php' type='submit' value='$id' name='button'>修改</button></td></tr></form>";
					}
				}
			}
				echo "</table>";
		}
		
	?>
</center>
</body>
</html>
<?php
	mysqli_close($link);
?>