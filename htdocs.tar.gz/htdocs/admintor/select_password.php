<?php
session_start();
$link = mysqli_connect('localhost','root','456789','bsglxt');//连接数据库
mysqli_query($link,'set names utf8');
$password = $_POST['password'];
	$sqla = "select password from t_administrator where admin_id = $_SESSION[id]";
	$res = mysqli_query($link,$sqla);
	while($row = mysqli_fetch_array($res)){
		$pas = $row['password'];
	}
	if ($pas == $password){
		$sqlb = "select * from t_student order by student_id asc";
		$resb = mysqli_query($link,$sqlb);
		$sqc = "select * from t_teacher order by teacher_id asc";
		$resc = mysqli_query($link,$sqc);
	}else {
		echo("<script>alert('密码错误');window.history.back(-1);</script>");
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <style>
    	table{
    		width: 80%;
    	}
    </style>
</head>
<body>
<center>
    <h3>教师密码</h3>
    <table>
        <tr>
            <td>账号</td><td>姓名</td><td>密码</td>
        </tr>
        <?php
        	while(@$row = mysqli_fetch_array($resc)){
        		echo "<tr><td>$row[teacher_id]</td><td>$row[name]</td><td>$row[password]</td></tr>";
        	}
        ?>
    </table>
    <h3>学生密码</h3>
    <table>
        <tr>
            <td>账号</td><td>姓名</td><td>密码</td>
        </tr>
        <?php
        	while(@$row = mysqli_fetch_array($resb)){
        		echo "<tr><td>$row[student_id]</td><td>$row[name]</td><td>$row[password]</td></tr>";
        	}
        ?>
    </table>
</center>
</body>
</html>
<?php
mysqli_close($link);