<?php
$link = mysqli_connect('localhost','root','456789','bsglxt');//连接数据库
mysqli_query($link,'set names utf8');
$button = $_POST['button'];
$sql = "update t_subject set state = 1 where subject_id = $button";
mysqli_query($link,$sql);
echo("<script>alert('审核通过');window.history.back(-1);</script>");
mysqli_close($link);
?>