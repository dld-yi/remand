<?php 
session_start();
if ($_SESSION['name']  == null) {
	echo '<center><h3>请重新登录!</h3></center>';
	// require("../index.html");
	exit();
}
?>
<!doctype html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style type="text/css" media="all">
    	a{
    		color: blue;
    		font-size: 120%;
    		text-decoration: none;
    	}
    </style>
</head>
<body>
	<br /><br />
<a href="reset_student.php">查看学生重置密码请求</a><br /><br />
<a id="a1" href="" onclick="fun()">重置所有学生密码</a><br /><br />
<a id="a2" href="" onclick="funa()">重置教师密码</a><br /><br />
<a id="" href="admin_oka.php" >查看所有密码</a><br /><br />
<script>
	function fun(){
		var arr = confirm("确定重置所有学生密码？");
		if(arr){
			document.getElementById("a1").href = "admin_oks.php";	
		}else{
			document.getElementById("a1").href = "reset_password.php";
		}
	}
	function funa(){
		var arr = confirm("确定重置所有教师密码？");
		if(arr){
			document.getElementById("a2").href = "admin_okt.php";	
		}else{
			document.getElementById("a2").href = "reset_password.php";
		}
	}
</script>
</body>
</html>