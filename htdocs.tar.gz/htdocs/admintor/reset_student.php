<?php
$link = mysqli_connect('localhost','root','456789','bsglxt');//连接数据库
mysqli_query($link,'set names utf8');
$sql = "select * from t_password";
$res = mysqli_query($link,$sql);
$num = mysqli_num_rows($res);
?>
<!doctype html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style type="text/css" media="all">
    	table{
    		margin-top:50px ;
    	}
    	td{
    		text-align: center;
    	}
    	.d1{
    		width: 10em;
    	}
    	.d2{
    		width: 3em;
    	}
    	.d3{
    		width: 11em;
    	}
    	.d4{
    		width: 10em;
    	}
    	.d5{
    		width: 4em;
    	}
    	.d6{
    		outline: none;
    		background-color:transparent;
            margin: 0px;
            padding: 0px;
            outline: none;
            border-width: 0px;
            font-size: 100%;
            color: blue;
    	}
    	.d7{
    		background-color:transparent;
    		border-width:0;
    		text-align: center;
    		width: 100%;
    		height: 100%;
    		font-size: 100%;
    	}
    	a{
    		text-decoration: none;
    	}
    </style>
</head>
<body>
<center>

		<table border="1"  cellspacing="0">
		
		<?php
			if($num == 0){
				echo("无申请信息");
			}else {
				echo "<tr><td>学号</td><td>姓名</td><td>电话</td><td>日期</td><td>请求驳回</td></tr>";
				while($row = mysqli_fetch_array($res)){
					$id = $row['id'];
					$time = $row['m_date'];
					$sqla = "select * from t_student where student_id = $id";
					$resa = mysqli_query($link,$sqla);
					while(@$rows = mysqli_fetch_array($resa)){
						echo "
						<form method='post' action='delete_reset.php'><tr><td class='d1'><input type='text' readonly class='d7' name='text' value='$rows[student_id]'></td><td class='d2'>$rows[name]</td><td class='d3'>$rows[phone]</td><td class='d4'>$time</td><td class='d5'><input class='d6' type = 'submit' value = '删除'></td></tr></form>";
					}
				}
			}
		?>
		<tr><td colspan="5"><a href="all_reset.php">一键重置</a></td></tr>
	</table>
</center>
</body>
</html>
<?php
	mysqli_close($link);
?>