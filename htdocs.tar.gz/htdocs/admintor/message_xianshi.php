<?php
	session_start();
	if ($_SESSION['name']  == null) {
		echo '<center><h3>请重新登录!</h3></center>';
		// require("../index.html");
		exit();
	}
    $link = mysqli_connect('localhost','root','456789','bsglxt');//连接数据库
    mysqli_query($link,'set names utf8');
    $i = 1;
    $j = 1;
    echo("学生通知：");
    echo("</br>");
    $sql = "select * from t_message where type = 0 order by m_date desc";
    $res = mysqli_query($link,$sql);
    if (!$res) {
    	// echo("<script>alert('查询失败');window.history.back(-1);</script>");
    	// code...
    }else {
    	$num = mysqli_num_rows($res);
    if($num != 0){
        while ($row = mysqli_fetch_array($res)){
            echo  "<form action = 'message_xiangxi.php' method = 'post'>","$i",",","<input type='submit' name='button' value='$row[name]'>"," ","<button formaction='delete_message.php' type='submit' value='$row[name]' name='button'>删除</button>","  ","$row[m_date]</form>";
            echo "</br>";
            $i++;
        }
    }
    else{
        echo "无信息";
    }
    }
    echo("<hr>");
    echo("教师通知：");
    echo("</br>");
    $sql = "select * from t_message where type = 1 order by m_date desc";
    $res = mysqli_query($link,$sql);
    if (!$res) {
    	// echo("<script>alert('查询失败');window.history.back(-1);</script>");
    	// code...
    }else {
    	$num = mysqli_num_rows($res);
    if($num != 0){
        while ($row = mysqli_fetch_array($res)){
            echo  "<form action = 'message_xiangxi.php' method = 'post'>","$j",",","<input type='submit' name='button' value='$row[name]'>"," ","<button formaction='delete_message.php' type='submit' value='$row[name]' name='button'>删除</button>","  ","$row[m_date]</form>";
            echo "</br>";
            $j++;
        }
    }
    else{
        echo "无信息";
    }
    }
    mysqli_close($link);
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <style>
        * {
            margin: 0px;
            padding: 0px
        }
        input,button{
            background-color: transparent;
            color: #0000CC;
            margin: 0px;
            padding: 0px;
            outline: none;
            border-width: 0px;
            font-size: 100%;
            margin-top: 10px;
            margin-left: 5px;
        }
    </style>
</head>
<body>

</body>
</html>