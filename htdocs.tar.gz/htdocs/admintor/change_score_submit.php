<?php
	$link = mysqli_connect('localhost', 'root', '456789', 'bsglxt');//连接数据库
	mysqli_query($link, 'set names utf8');
	$id = $_POST['button'];
	$ad = $_POST['zhidao'];
	$py = $_POST['pingyue'];
	$db = $_POST['dabian'];
	$zc = $ad*0.2 + $py*0.4 + $db*0.4;
	$sql = "update t_score set adviser = '$ad',review = '$py',reply = '$db',points = '$zc' where student_id = '$id'";
	mysqli_query($link,$sql);
	echo "<script>alert('修改成功');window.history.back(-1);</script>";
	
	mysqli_close($link);