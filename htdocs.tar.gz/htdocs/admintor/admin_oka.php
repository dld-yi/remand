<!doctype html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style type="text/css" media="all">
    	input{
    		margin-top: 150px;
    	}
    </style>
</head>
<body>
<center>
	<form action="select_password.php" method="post">
		<input type="password" name="password" placeholder="请输入管理员密码">
		<input type="submit" value="确定">
	</form>
</center>
</body>
</html>