<?php
session_start();
$link = mysqli_connect('localhost', 'root', '456789', 'bsglxt');//连接数据库
mysqli_query($link, 'set names utf8');
$id = $_SESSION['id'];
$ops = $_POST['ops'];
$nps = $_POST['nps'];
$nnps = $_POST['nnps'];
if ($_POST['submit'] == '确定') {
	$sql = "select * from t_administrator where admin_id = $id";
	$res = mysqli_query($link,$sql);
	while($row = mysqli_fetch_array($res)){
		$oops = $row['password'];
	}
	if($ops == $oops){
		if($nps == $nnps){
			$sqla = "update t_administrator set password = $nps where admin_id = $id";
			$res = mysqli_query($link,$sqla);
			if(!$res){
				echo("<script>alert('修改失败');window.history.back(-1);</script>");
			}else{
				echo("<script>alert('修改成功');</script>");
				session_unset();
				session_destroy();
				echo("</br>");
				echo '<center><h3>请重新登录!</h3></center>';
			}
		}else{
			echo("<script>alert('两次密码输入不一样，修改失败');window.history.back(-1);</script>");
		}
	}else{
		echo("<script>alert('原密码输入错误，修改失败');window.history.back(-1);</script>");
	}
}

?>