<?php
session_start();
$link = mysqli_connect('localhost','root','456789','bsglxt');//连接数据库
mysqli_query($link,'set names utf8');
$id = $_SESSION['id'];
$name = $_POST['name'];
$content = $_POST['content'];
$type = $_POST['type'];
$time = date('Y-m-d');
$sql = "insert into t_message (admin_id,name,description,type,m_date) values('$id','$name','$content','$type','$time')"; 
if(mysqli_query($link,$sql)){
	echo("<script>alert('发布成功');window.history.back(-1);</script>");
}else {
	echo("<script>alert('发布失败');window.history.back(-1);</script>");
}

mysqli_close($link);

?>