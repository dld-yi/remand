<?php
$link = mysqli_connect('localhost','root','456789','bsglxt');//连接数据库
mysqli_query($link,'set names utf8');
$id = $_POST['text'];
$sql = "delete from t_password where id = $id";
$res = mysqli_query($link,$sql);
if (!$res) {
	echo("<script>alert('删除失败');window.history.back(-1);</script>");
}else {
	echo("<script>alert('删除成功');window.history.back(-1);</script>");
	require("reset_student.php");
}
?>