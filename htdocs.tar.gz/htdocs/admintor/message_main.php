<?php 
session_start();
if ($_SESSION['name']  == null) {
	echo '<center><h3>请重新登录!</h3></center>';
	exit();
}
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <title>信息发布</title>
    <style>
        body{
            background-color: transparent;
        }
        #name{
            width: 99%;
        }
        .STYLE2{
            position: relative;
            left: 30px;
        }
    </style>
</head>
<body>
<h2 align="center">发布通知</h2>
<table align="center" width="60%" border="1" cellspacing="0">
    <form action="message.php" name="message" id="message" method="post">
        <tr>
            <td align="center">消息名称</td>
            <td width="80%" align="center"><input required type="text" name="name" maxlength="50" id="name"></td>
        </tr>
        <tr>
            <td align="center">消息类型</td>
            <td>
                <select name="type" class="STYLE2" id="type">
                    <option value="0" selected="selected">学生通知</option>
                    <option value="1">教师通知</option>
                </select>
            </td>
        </tr>
        <tr>
            <td align="center">消息内容</td>
            <td><textarea required name="content" id="content" cols="100" rows="15"></textarea></td>
        </tr>
        <tr>
            <td align="center"><input type="submit"  value="确认发布"></td>
            <td><input type="reset" value="重新填写" class="STYLE2"></td>
        </tr>
    </form>
</table>
</body>
</html>