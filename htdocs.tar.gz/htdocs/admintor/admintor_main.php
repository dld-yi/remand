<?php session_start(); ?>
<!doctype html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <meta>
    <title>管理员首页</title>
    <style>
        body{
            background: url('image/t10.jpg') no-repeat;
            background-size: 100%;
                -webkit-background-size: cover;
				-o-background-size: cover;                
				background-size: cover;
        }
        *{
            padding: 0px;
            margin: 0px;
        }
        .headerA{
            position: relative;
            width: 80%;
            height: 100px;
            left: 130px;
        }
        .divTwo{
            position: relative;
            font-size: 450%;
            font-family: 隶书;
            left: 280px;
            top:5px;
            transform: rotate(-2deg);
        }
        a{
        	color: blue;
            font-size: 150%;
            font-family: 隶书;
        }
        button{
        	background-color: transparent;
        }
        table{
        	background: url('image/t9.jpg') no-repeat;
        	background-size: 100%;
                -webkit-background-size: cover;
				-o-background-size: cover;                
				background-size: cover;
        }
        .t7{
        	background: url('image/t7.jpg') no-repeat;
        	background-size: 100%;
                -webkit-background-size: cover;
				-o-background-size: cover;                
				background-size: cover;
        }
    </style>
</head>

<body scroll="no" style="overflow-x:hidden;overflow-y:hidden">
<header class="headerA"><div class="divTwo"><p>毕业设计管理系统</p></div></header>
<center>
    <hr width="80%">
    <table width="80%" border="0" >
        <tr>
            <td width="20%" class="t7"><button onclick="fun()"><<</button>   欢迎您：<?php echo $_SESSION['name']," "; ?>老师</td>
            <center><td>今天是：
                    <?php
                    echo date('Y ')."年".date('m')."月".date('d')."日";
                    switch(date('w'))
                    {
                        case 0:
                            echo date('星期日');
                            break;
                        case 1:
                            echo date('星期一');
                            break;
                        case 2:
                            echo date('星期二');
                            break;
                        case 3:
                            echo date('星期三');
                            break;
                        case 4:
                            echo date('星期四');
                            break;
                        case 5:
                            echo date('星期五');
                            break;
                        case 6:
                            echo date('星期六');
                            break;
                    }
                    ?>
                </td> </center>
            <td align="right"><a href="../logout.php">退出&nbsp;&nbsp;</a>
        </tr>
        <tr>
            <td align="center" class="t7">
                <p>&nbsp;</p>
                <p><a href="message_main.php" target="content">发布通知</a></p><br>
                <p><a href="message_xianshi.php" target="content">删除通知</a></p><br>
                <p><a href="change_password.php" target="content">修改密码</a></p><br>
                <p><a href="reset_password.php" target="content">重置密码</a></p><br>
                <p><a href="teacher_input.php" target="content">教师信息录入</a></p><br>
                <p><a href="student_input.php" target="content">学生信息录入</a></p><br>
                <p><a href="check_subject.php" target="content">审核毕业设计题目</a></p><br>
                <p><a href="select_paper.php" target="content">教师审核学生论文进度</a></p><br>
                <p><a href="student_score.php" target="content">学生最终成绩</a></p><br>
                <br>
            </td>
            <td colspan="2"><iframe src="message_main.php" name="content" width="100%" height="500px" frameborder="0"></iframe></td>
        </tr>
    </table>
</center>
<script>
	function fun(){
		window.history.back(-1);
	}
</script>
</body>
</html>
