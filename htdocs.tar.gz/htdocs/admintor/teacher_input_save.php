<?php
$link = mysqli_connect('localhost','root','456789','bsglxt');//连接数据库
mysqli_query($link,'set names utf8');
$id = $_POST['zhanghao'];
$name = $_POST['xingming'];
$num = $_POST['num'];
$sql = "select * from t_teacher where teacher_id = $id";
$res = mysqli_query($link,$sql);
$numa = mysqli_num_rows($res);
if($numa != 0){
	echo("<script>alert('已有此教师账号');window.history.back(-1);</script>");
}else {
	$sql = "insert into t_teacher(teacher_id,password,name,num) values('$id','$id','$name','$num')";
	$res = mysqli_query($link,$sql);
	echo("<script>alert('添加成功');window.history.back(-1);</script>");

}

mysqli_close($link);
?>