<?php
	// $link = mysqli_connect('localhost', 'root', '456789', 'bsglxt');//连接数据库
	// mysqli_query($link, 'set names utf8');
	$id = $_POST['button'];
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<center>
	<h2>成绩修改</h2>
	<table>
		<tr>
			<td>学号</td>
			<td>指导教师成绩</td>
			<td>评阅教师成绩</td>
			<td>答辩成绩</td>
			<td>确认修改</td>
		</tr>
		<form action='' method='post'>
			<tr>
				<td><?php echo $id; ?></td>
				<td><input type='text' name='zhidao' maxlength='3'></td>
				<td><input type='text' name='pingyue' maxlength='3'></td>
				<td><input type='text' name='dabian' maxlength='3'></td>
				<td><button formaction='change_score_submit.php' name='button' type='submit' value='<?php echo $id; ?>'>提交</button></td>
			</tr>
		</form>
	</table>
</center>
</body>
</html>
