<?php 
session_start();
if ($_SESSION['name']  == null) {
	echo '<center><h3>请重新登录!</h3></center>';
	// require("../index.html");
	exit();
}
$link = mysqli_connect('localhost','root','456789','bsglxt');//连接数据库
mysqli_query($link,'set names utf8');

?>
<!doctype html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style type="text/css" media="all">
    * {
            margin: 0px;
            padding: 0px
        }
        input,button{
            background-color: transparent;
            color: #0000CC;
            margin: 0px;
            padding: 0px;
            outline: none;
            border-width: 0px;
            font-size: 100%;
            margin-top: 10px;
            margin-left: 5px;
        }
        td{
        	text-align: center;
        }
        a{
        	text-decoration: none;
        	margin-top: 50px;
        }
        table{
        	width: 80%;
        	margin-top: 50px;
        }
        h2{
        	margin-top: 50px;
        }
    </style>
</head>
<body>
<center>
		<h2>审核请求</h2>
		<table border="1"  cellspacing="0">
		
		<?php
		$sql = "select * from t_subject order by subject_id";
		$res = mysqli_query($link,$sql);
		$num = mysqli_num_rows($res);
			if($num == 0){
				echo("无审核信息");
			}else {
				echo "<tr><td>课题编号</td><td>教师工号</td><td>姓名</td><td>职称</td><td>题目</td><td>审核状态</td><td>操作</td></tr>";
				while($row = mysqli_fetch_array($res)){
					$id = $row['subject_id'];
					$ida = $row['teacher_id'];
					$sqls = "select * from t_teacher where teacher_id = $ida";
					$ress = mysqli_query($link,$sqls);
					while($rows = mysqli_fetch_array($ress)){
						$teacherName = $rows['name'];
						$title = $rows['title'];
					}
					$name = $row['name'];
					$state = $row['state'];
					echo "<form action = '' method = 'post'><tr><td>$id</td><td>$ida</td><td>$teacherName</td><td>$title</td><td><button type='submit' name='button' formaction='check_subject_xiangxi.php' value='$id'>$name</button></td>";
					if($state == 0){
						echo "<td>待审核</td><td><button formaction='check_subject_pass.php' type='submit' value='$id' name='button'>通过</button> <button formaction='check_subject_refuse.php' type='submit' value='$id' name='button'>返回修改</button></td></tr></form>";
					}elseif ($state == 1) {
						echo "<td>审核通过</td><td>已审核</td></tr></form>";
					}elseif($state == 2){
						echo "<td>审核不通过</td><td>已审核</td></tr></form>";
					}
				}
			}
		?>
		<tr><td colspan="8"><a href="check_subject_allpass.php">全部通过</a></td></tr>
	</table>
</center>
</body>
</html>
<?php
	mysqli_close($link);
?>