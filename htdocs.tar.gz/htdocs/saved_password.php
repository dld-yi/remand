<?php
session_start();
$link = mysqli_connect('localhost', 'root', '456789', 'bsglxt');//连接数据库
mysqli_query($link, 'set names utf8');
$type = $_SESSION['type'];
$id = $_SESSION['id'];
$ops = $_POST['ops'];
$nps = $_POST['nps'];
$nnps = $_POST['nnps'];
if ($_POST['submit'] == '确定') {
	if($type == 'student'){
		$sql = "select * from t_student where student_id = $id";
	}else{
		$sql = "select * from t_teacher where teacher_id = $id";
	}
	$res = mysqli_query($link,$sql);
	while($row = mysqli_fetch_array($res)){
		$oops = $row['password'];
	}
	if($ops == $oops){
		if($nps == $nnps){
			if($type == 'student'){
				$sql = "update t_student set password = $nps where student_id = $id";
			}else{
				$sql = "update t_teacher set password = $nps where teacher_id = $id";
			}
			$res = mysqli_query($link,$sql);
			if(!$res){
				echo("<script>alert('修改失败');window.history.back(-1);</script>");
			}else{
				echo("<script>alert('修改成功');</script>");
				session_unset();
				session_destroy();
				echo("</br>");
				echo("</br>");
				header("refresh:3;url=//www.dld-yi.top");
				print('请稍等...<br>三秒后自动跳转到登录页面~~~');
			}
		}else{
			echo("<script>alert('两次密码输入不一样，修改失败');window.history.back(-1);</script>");
		}
	}else{
		echo("<script>alert('原密码输入错误，修改失败');window.history.back(-1);</script>");
	}
}

?>