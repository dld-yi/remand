<!doctype html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes, minimum-scale=1.0, maximum-scale=1.0"/>
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>学生注册</title>
    <style>
        table{
            position: relative;
            width: 30%;
            margin: auto;
            text-align: center;
            top: 50px;
        }
        .d1{
            width: 30%;
        }
        .d2{
            width: 95%;
            border: none;
        }
        .d3{
            color: red;
        }
        .d4{
            width: 95%;
            border: none;
        }
        .d5{
        	border-left: 0px;
        	border-right: 0px;
        	border-bottom: 0px;
        }
        .d6{
        	width: 50%;
        }
        /*#submit{*/
        /*	position: relative;*/
        /*	left: 580px;*/
        /*	top: 80px;*/
        /*	width: 50px;*/
        /*	height: 30px;*/
        /*}*/
        /*#button{*/
        /*	position: relative;*/
        /*	top: 80px;*/
        /*	left: 680px;*/
        /*	width: 50px;*/
        /*	height: 30px;*/
        /*}*/
    </style>
    <script type="text/javascript"></script>
</head>
<body>
<form action="sign_login.php" method="post" accept-charset="utf-8">
	<center>
				<table border="1" cellspacing="0">
		    <tr>
		        <td colspan="2" style="text-align: center">基本信息</td>
		    </tr>
		    <tr>
		        <td class="d1">学号</td>
		        <td class="d3"><input type="text" class="d2" pattern="(\d){6,10}" required name="zhanghao">*</td>
		    </tr>
		    <tr>
		        <td class="d1">密码</td>
		        <td class="d3"><input type="password" class="d2" maxlength="20" required name="mima">*</td>
		    </tr>
		    <tr>
		        <td class="d1">确认密码</td>
		        <td class="d3"><input type="password" class="d2" required name="querenmima">*</td>
		    </tr>
		    <tr>
		        <td class="d1">姓名</td>
		        <td class="d3"><input type="text" class="d2" required name="xingming">*</td>
		    </tr>
		    <tr>
		        <td class="d1">年龄</td>
		        <td class="d3"><input type="text" class="d4" name="nianling" pattern="\d{2}"></td>
		    </tr>
		    <tr>
		        <td class="d1">班级</td>
		        <td class="d3"><input type="text" class="d2" required name="banji">*</td>
		    </tr>
		    <tr>
		        <td class="d1">院系</td>
		        <td class="d3"> <select name="role" id="role" class="">
                            <option value="理工学部" selected>理工学部</option>
                            <option value="人文学部">人文学部</option>
                            <option value="医学部">医学部</option>
                        </select>*</td>
		    </tr>
		    <tr>
		        <td class="d1">qq</td>
		        <td class="d3"><input type="text" class="d4" name="qq" pattern="\d{5,11}"></td>
		    </tr>
		    <tr>
		        <td class="d1">电话</td>
		        <td class="d3"><input type="text" class="d2" required name="phone" pattern="^1(3|4|5|7|8)\d{9}$">*</td>
		    </tr>
		    <tr>
		        <td class="d1">邮箱</td>
		        <td class="d3"><input type="text" class="d2" required name="email" pattern="^[a-zA-Z0-9_.-]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z0-9]{2,6}$">*</td>
		    </tr>
		    <tr>
				<td class="d5"><input class="d6" type="submit" name="submit" id="submit" value="注册" /></td>
				<td class="d5"><input class="d6" type="button" name="button" id="button" value="取消" onclick="fun()"/></td>
			</tr>
		</table>
	</center>

</form>
<script>
	function fun(){
		window.history.back();
	}
</script>
</body>
</html>
