<?php
session_start();
if ($_SESSION['name']  == null) {
	echo '<center><h3>请重新登录!</h3></center>';
	// require("../index.html");
	exit();
}
$link = mysqli_connect('localhost', 'root', '456789', 'bsglxt');//连接数据库
mysqli_query($link, 'set names utf8');

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <style>
    	table{
    		width: 80%;
    	}
    </style>
</head>
<body>
<center>
	<h2>成绩录入</h2>
	<?php
		$sql = "select * from t_subject where teacher_id = '$_SESSION[id]' and choose = 1";
		$res = mysqli_query($link,$sql);
		$num = mysqli_num_rows($res);
		if($num == 0){
			echo("<script>alert('还未有人选题');</script>");
		}else {
			echo "<table  cellspacing='0' border='0'>";
			echo "<tr><td>学号</td><td>姓名</td><td>指导教师成绩</td><td>上传</td></tr>";
			while($row = mysqli_fetch_array($res)){
				$subjectId = $row['subject_id'];
				$sqlb = "select * from t_student_subject where subject_id = '$subjectId'";
				$resb = mysqli_query($link,$sqlb);
				while($rowb = mysqli_fetch_array($resb)){
					$studentId = $rowb['student_id'];
				}
				$sqlc = "select * from t_paper where student_id = '$studentId'";
				$resc = mysqli_query($link,$sqlc);
				$sqlm = "select * from t_student where student_id = '$studentId'";
				$resm = mysqli_query($link,$sqlm);
				while($rowm = mysqli_fetch_array($resm)){
					$studentName = $rowm['name'];
				}
				$numc = mysqli_num_rows($resc);
				if($numc != 0){
					$sqld = "select * from t_score where student_id = '$studentId'";
					$resd = mysqli_query($link,$sqld);
					$numd = mysqli_num_rows($resd);
					if($numd == 0){
					echo "<form action='' method='post'><tr><td>$studentId</td><td>$studentName</td><td><input type='text' name='zhidao' maxlength='3'></td><td><button formaction='submit_score.php' name='button' type='submit' value='$studentId'>提交</button></td></tr></form>";
					}else{
						echo "<form action='' method='post'><tr><td>$studentId</td><td colspan = '4' align='right'>已录入</td></tr></form>";
					}
				}
			
			}
			echo "</table>";
		}
	?>
	</table>
</center>
<script>
	
</script>
</body>
</html>
<?php
	mysqli_close($link);
?>