<?php
session_start();
if ($_SESSION['name']  == null) {
	echo '<center><h3>请重新登录!</h3></center>';
	// require("../index.html");
	exit();
}
$link = mysqli_connect('localhost','root','456789','bsglxt');//连接数据库
mysqli_query($link,'set names utf8');
$id = $_SESSION['id'];
$sql = "select * from t_subject where teacher_id = '$id' and choose = '1'";
$res = mysqli_query($link,$sql);
$num = mysqli_num_rows($res);
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Document</title>
  <style>
  	td{
  		text-align: center;
  	}
  	button{
  		background-color: transparent;
            color: #0000CC;
            margin: 0px;
            padding: 0px;
            outline: none;
            border-width: 0px;
            font-size: 100%;
            margin-top: 10px;
            margin-left: 5px;
  	}
  	table{
  		margin-top: 50px;
  		width: 80%;
  	}
  </style>
</head>
<body>
<center>
	<?php
		if($num == 0){
			echo "<h2>您的课题还未被选择</h2>";
		}else {
			echo "<h2>学生已选择课题</h2>";
			echo "<table border = '1' cellspacing='0'>";
			echo "<tr><td>编号</td><td>学号</td><td>姓名</td><td>班级</td><td>课题名称</td><td>状态</td><td>审核</td></tr>";
			while($row = mysqli_fetch_array($res)){
				$subjectId = $row['subject_id'];
				$name = $row['name'];
				$sqla = "select * from t_student_subject where subject_id = $subjectId ";
				@$resa = mysqli_query($link,$sqla);
				while(@$rowa = mysqli_fetch_array($resa)){
					$studentId = $rowa['student_id'];
					$state = $rowa['state'];
				}
				$sqlb = "select * from t_student where student_id = $studentId";
				@$resb = mysqli_query($link,$sqlb);
				while(@$rowb = mysqli_fetch_array($resb)){
					$namea = $rowb['name'];
					$class = $rowb['class'];
				}
				echo "<form action = 'subject_student_message.php' method = 'post'><tr><td>$subjectId</td><td>
						<button type='submit' name='button' formaction='subject_student_message.php' value='$studentId'>$studentId</button></td><td>$namea</td><td>$class</td><td><button type='submit' name='button' formaction='check_subject_xiangxi.php' value='$subjectId'>$name</button></td>";
				if($state == 0){
				echo "<td>待审核</td><td><button type='submit' name='button' formaction='check_subject_student_ok.php' value='$subjectId'>通过</button><button type='submit' name='button' formaction='check_subject_student_not.php' value='$subjectId'>不通过</button></td></tr></form>";
					
				}elseif($state == 1){
				echo	"<td>已审核</td><td>已通过</td></tr></form>";
				}else{
				echo	"<td>已审核</td><td>未通过</td></tr></form>";
				}
			}
			echo "</table>";
		}
	?>
</center>
</body>
</html>
<?php
mysqli_close($link);
?>