<?php 
$link = mysqli_connect('localhost','root','456789','bsglxt');//连接数据库
mysqli_query($link,'set names utf8');
$id = $_POST['button'];
$sql = "select * from t_subject where subject_id = '$id'";
$res = mysqli_query($link,$sql);
while($row = mysqli_fetch_array($res)){
	$name = $row['name'];
	$de = $row['department'];
	$ma = $row['major'];
	$ty = $row['type'];
	$lai = $row['source'];
	$content = $row['description'];
	$suggestion = $row['suggestion'];
}
?>
<!doctype html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>上传毕业设计题目</title>
    <style>
        .d1{
            width: 24px;
        }
        .d3{
            position: relative;
            margin-left: 130px;
        }
    </style>
</head>
<body>
<center>
    <h2 align="center">上传毕业设计题目</h2>
    <form action="check_subject_change_save.php" method="post">
        <table border="2" cellspacing="1" width="80%">
            <tr>
                <td class="d1">课题情况</td>
                <td class="d2">题目：<input type="text" name="timu" value="<?php echo $name; ?>"><hr>题目所属专业：<br>院系：<select name="role" id="role" class=""  value="<?php echo $de; ?>">
                            <option value="理工学部" selected>理工学部</option>
                            <option value="人文学部">人文学部</option>
                            <option value="医学部">医学部</option>
                        </select><br>
                        专业：<input type="text" name="major" value="<?php echo $ma; ?>"><hr>
                        题目性质：<br>
                        题目类型：<input type="text" name="type" value="<?php echo $ty; ?>"><br>
                        题目来源：<input type="text" name="laiyuan" value="<?php echo $lai; ?>">
                </td>
            </tr>
            <tr>
                <td class="d1">主要研究内容</td>
                <td class="d2"><textarea name="shuoming" id="" cols="100%" rows="8"><?php echo $content; ?></textarea></td>
            </tr>
            <tr>
                <td class="d1">目标和要求</td>
                <td class="d2"><textarea name="jianyi" id="" cols="100%" rows="8"><?php echo $suggestion; mysqli_close($link); ?></textarea></td>
            </tr>
            <tr>
                <td colspan="2"><button type='submit' name='button' formaction='check_subject_change_save.php' value='<?php echo $id; ?>'>确认修改</button>
                    <input type="reset" class="d4" value="重新填写"></td>
            </tr>
        </table>
    </form>
</center>
</body>
</html>
