<?php
session_start();
if ($_SESSION['name']  == null) {
	echo '<center><h3>请重新登录!</h3></center>';
	// require("../index.html");
	exit();
}
$link = mysqli_connect('localhost', 'root', '456789', 'bsglxt');//连接数据库
mysqli_query($link, 'set names utf8');

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <style>
    	table{
    		width: 80%;
    	}
    </style>
</head>
<body>
<center>
	
	<h2>已录入的学生的成绩</h2>
	<table id="table">
		<?php
			echo "<tr><td>学号</td><td>姓名</td><td>指导教师成绩</td><td>评阅教师成绩</td><td>答辩成绩</td><td>总分</td></tr>";
			$sql = "select * from t_subject where teacher_id = '$_SESSION[id]' and choose = 1";
			$res = mysqli_query($link,$sql);
				while($row = mysqli_fetch_array($res)){
				$subjectId = $row['subject_id'];
				$sqlb = "select * from t_student_subject where subject_id = '$subjectId'";
				$resb = mysqli_query($link,$sqlb);
				while($rowb = mysqli_fetch_array($resb)){
					$studentId = $rowb['student_id'];
				}
				$sqlm = "select * from t_student where student_id = '$studentId'";
				$resm = mysqli_query($link,$sqlm);
				while($rowm = mysqli_fetch_array($resm)){
					$studentName = $rowm['name'];
				}
				$sqlc = "select * from t_score where student_id = '$studentId'";
				$resc = mysqli_query($link,$sqlc);
				while($rowc = mysqli_fetch_array($resc)){
					$ad = $rowc['adviser'];
					$py = $rowc['review'];
					$re = $rowc['reply'];
					$po = $rowc['points'];
					echo "<tr><td>$studentId</td><td>$studentName</td><td>$ad</td><td>$py</td><td>$re</td><td>$po</td></tr>";
				}
				
			}
			
			
		?>
	</table>
</center>
<script>
	
</script>
</body>
</html>
<?php
	mysqli_close($link);
?>