<?php 
session_start();
if ($_SESSION['name']  == null) {
	echo '<center><h3>请重新登录!</h3></center>';
	// require("../index.html");
	exit();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>审核论文</title>
<style type="text/css">
a{
	text-decoration: none;
}
</style></head>
<body class="STYLE2" vlink="#0000CC"><br />
<p><h2 align="center">审核学生论文</h2>
<?php
	 $link = mysqli_connect('localhost', 'root', '456789', 'bsglxt');//连接数据库
	mysqli_query($link, 'set names utf8');
	 $sql = "select distinct t_paper.paper_id,t_paper.location path,t_subject.name p_name,t_student.name s_name,t_student.student_id s_id,t_paper.state state,t_paper.score score
	 from t_paper,t_subject,t_student,t_student_subject where t_student.student_id = t_paper.student_id and t_subject.subject_id=t_student_subject.subject_id and t_subject.teacher_id = '$_SESSION[id]'
	 and t_paper.student_id=t_student_subject.student_id";
	 $res = mysqli_query($link,$sql);
	 @$num = mysqli_num_rows($res);
	 //echo $sql;
	 if($num>0)
	 {
	    echo "<table align=center cellspacing='2' width='100%'><tr>";
		echo "<td align=center>序号</td>";
		echo "<td align=center>论文</td>";
		echo "<td align=center>学生</td>";
		echo "<td align=center>状态</td>";
		echo "<td align=center>审核</td>";
		echo "</tr>";
		$i = 0;
	    while($row = mysqli_fetch_array($res))
		{
		   echo "<form action='check_paper.php' method='post'><tr>";
		   echo "<td align=center>".($i+1)."</td>";
		   echo "<td align=center>"."<a href=\"../student/".$row['path']."\">".$row['p_name']."</a></td>";
		   echo "<td align=center>".$row['s_name']."(".$row['s_id'].")</td>";
		   if($row['state']<3){
		   	if($row['state'] == 0){
		   		if($row['score'] == 0){
				   echo "<td align=center>1审还没有完成</td>";
		   		}
		   		elseif ($row['score'] < 60 && $row['score'] > 0) {
		   			echo "<td align=center>1还没有通过</td>";
		   		}else{
	   				echo "<td align=center>1审已通过</td>";
		   		}
		   	}else{
		   		if($row['score'] == 0){
				   echo "<td align=center>",$row['state']+1,"审还没有完成</td>";
		   		}
		   		elseif ($row['score'] < 60 && $row['score'] > 0) {
		   			echo "<td align=center>",$row['state']+1,"审还没有通过</td>";
		   		}else{
	   				echo "<td align=center>",$row['state'],"审已通过</td>";
		   		}}
				   echo "<td align=center>";
				   echo "<input name='paper_id' type='hidden' value='".$row['paper_id']."'/>";
				   echo "评分：<input name='score' type='text' size='5' maxlength='3'/>";
				   echo "<input name='submit' type='submit' value='提交'/>";
		   }
		   else{
			   	echo "<td align=center>","3审已通过</td>";
			   echo "<td align=center>审核已全部通过";
		   }
		   echo "</td></tr></form>";
		   $i++;
		}
		echo "</table>";
	}
?>
<?php
 $paper_id = @$_POST['paper_id'];
 $score = @$_POST['score'];
 $submit = @$_POST['submit'];
 if($submit=="提交")
 {
 	if($score >= 60){
	   $sql = "update t_paper set score = '$score',state = state + 1 where paper_id='$paper_id'";
	   if(mysqli_query($link,$sql)){
	    echo "<br/><h2 align='center'>论文","$paper_id","审核成功</h2>";
	   }
 	}else {
 		$sql = "update t_paper set score = '$score' where paper_id='$paper_id'";
	   if(mysqli_query($link,$sql)){
	    echo "<br/><h2 align='center'>论文","$paper_id","审核成功</h2>";
 	}
 }
 }
mysqli_close($link);
?>
</p>
</body>
</html>
