<?php
session_start();
$link = mysqli_connect('localhost', 'root', '456789', 'bsglxt');//连接数据库
mysqli_query($link, 'set names utf8');
$id = $_POST['button'];
$name = $_POST['timu'];
$role = $_POST['role'];
$major = $_POST['major'];
$type = $_POST['type'];
$laiyuan = $_POST['laiyuan'];
$content = $_POST['shuoming'];
$suggest = $_POST['jianyi'];

$sql = "update t_subject set name = '$name',department = '$role',major = '$major',type = '$type',source = '$laiyuan',description = '$content',suggestion = '$suggest',state = '0',choose = '0' where subject_id = '$id'";
mysqli_query($link,$sql);
echo("<script>alert('上传成功，请等待审核');window.history.back(-1);</script>");

	

mysqli_close($link);
?>