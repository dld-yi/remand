<!doctype html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>公告</title>
    <style>
        input{
            background-color: transparent;
            color: #0000CC;
            margin: 0px;
            padding: 0px;
            outline: none;
            border-width: 0px;
            font-size: 100%;
            margin-top: 10px;
            margin-left: 5px;
        }
    </style>
</head>
<body>
<form action="message_xiangxi.php" method="get">
    <?php
    $link = mysqli_connect('localhost','root','456789','bsglxt');//连接数据库
    mysqli_query($link,'set names utf8');
    $i = 1;
    $sql = "select * from t_message where type = 1 order by m_date desc";
    $res = mysqli_query($link,$sql);
    if (!$res) {
    	echo("<script>alert('查询失败');window.history.back(-1);</script>");
    }else {
    	$num = mysqli_num_rows($res);
    if($num != 0){
        while ($row = mysqli_fetch_array($res)){
        	echo "$i",",";
            echo  "<input type='submit' name='button' value='$row[name]'>","  ","$row[m_date]";
            echo "</br>";
            $i++;
        }
    }
    else{
        echo "无信息";
    }
    }
    mysqli_close($link);
    ?>
</form>
</body>
</html>