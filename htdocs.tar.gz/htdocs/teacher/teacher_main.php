<?php session_start(); ?>
<!doctype html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <title>教师首页</title>
    <style>
        body{
        	overflow:auto;
            background: url('image/t10.jpg') no-repeat;
            background-size: 100%;
                -webkit-background-size: cover;
				-o-background-size: cover;                
				background-size: cover;
        }
        *{
        	margin: 0px;
        	padding: 0px;
        }
        .headerA{
            position: relative;
            width: 80%;
            height: 100px;
            left: 130px;
        }
        .divTwo{
            position: relative;
            font-size: 450%;
            font-family: 隶书;
            left: 280px;
            top:5px;
            transform: rotate(-2deg);
        }
        a{
        	color: blue;
            font-size: 150%;
            font-family: 隶书;
        }
        button{
        	background-color: transparent;
        }
        table{
        	background: url('image/t9.jpg') no-repeat;
        	background-size: 100%;
                -webkit-background-size: cover;
				-o-background-size: cover;                
				background-size: cover;
        }
        .t7{
        	background: url('image/t7.jpg') no-repeat;
        	background-size: 100%;
                -webkit-background-size: cover;
				-o-background-size: cover;                
				background-size: cover;
        }
    </style>
</head>
<body scroll="no" style="overflow-x:hidden;overflow-y:hidden">
<header class="headerA"><div class="divTwo"><p>毕业设计管理系统</p></div></header>
<center>
    <hr width="80%">
    <table width="80%" border="0" >
        <tr>
            <td width="20%" class="t7"><button onclick="fun()"><<</button>   欢迎您：<?php echo $_SESSION['name']," "; ?>老师</td>
            <center><td>今天是：
                <?php
	          echo date('Y ')."年".date('m')."月".date('d')."日";
			  switch(date('w'))
			  {
			      case 0:
			      echo date('星期日');
				  break;
				  case 1:
			      echo date('星期一');
				  break;
				   case 2:
			      echo date('星期二');
				  break;
				   case 3:
			      echo date('星期三');
				  break;
				   case 4:
			      echo date('星期四');
				  break;
				   case 5:
			      echo date('星期五');
				  break;
				   case 6:
			      echo date('星期六');
				  break;
				}
	   ?>
            </td> </center>
            <td align="right"><a href="../logout.php">退出&nbsp;&nbsp;</a>
        </tr>
        <tr>
            <td align="center" class="t7">
                <p>&nbsp;</p>
                <p><a href="message_xianshi.php" target="content">教务通知</a></p><br>
                <p><a href="teacher_message.php" target="content">个人信息</a></p><br>
                <p><a href="change_password.php" target="content">修改密码</a></p><br>
                <p><a href="subject_uploding.php" target="content">上传毕业设计题目</a></p><br>
                <p><a href="subject_amend.php" target="content">修改毕业设计题目</a></p><br>
                <p><a href="check_subject_result.php" target="content">查看学生选题结果</a></p><br>
                <p><a href="check_paper.php" target="content">查看学生论文</a></p><br>
                <p><a href="input_score.php" target="content">成绩录入</a></p><br>
                <p><a href="check_score.php" target="content">查看成绩</a></p><br>
                <br>
            </td>
            <td colspan="2"><iframe src="message_xianshi.php" name="content" width="100%" height="500px" frameborder="0"></iframe></td>
        </tr>
    </table>
</center>
<script>
	function fun(){
		window.history.back(-1);
	}
</script>
</body>
</html>
