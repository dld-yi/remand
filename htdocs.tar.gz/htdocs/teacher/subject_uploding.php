<?php session_start();
if ($_SESSION['name']  == null) {
	echo '<center><h3>请重新登录!</h3></center>';
	// require("../index.html");
	exit();
}
?>
<!doctype html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>上传毕业设计题目</title>
    <style>
        .d1{
            width: 24px;
        }
        .d3{
            position: relative;
            margin-left: 130px;
        }
    </style>
</head>
<body>
<center>
    <h2 align="center">上传毕业设计题目</h2>
    <form action="subject_submit.php" method="post">
        <table border="2" cellspacing="1" width="80%">
            <tr>
                <td class="d1">课题情况</td>
                <td class="d2">题目：<input type="text" name="timu"><hr>题目所属专业：<br>院系：<select name="role" id="role" class="">
                            <option value="理工学部" selected>理工学部</option>
                            <option value="人文学部">人文学部</option>
                            <option value="医学部">医学部</option>
                        </select><br>
                        专业：<input type="text" name="major"><hr>
                        题目性质：<br>
                        题目类型：<input type="text" name="type"><br>
                        题目来源：<input type="text" name="laiyuan">
                </td>
            </tr>
            <tr>
                <td class="d1">主要研究内容</td>
                <td class="d2"><textarea name="shuoming" id="" cols="100%" rows="8"></textarea></td>
            </tr>
            <tr>
                <td class="d1">目标和要求</td>
                <td class="d2"><textarea name="jianyi" id="" cols="100%" rows="8"></textarea></td>
            </tr>
            <tr>
                <td colspan="2"><input type="submit" class="d3" value="确认上传">
                    <input type="reset" class="d4" value="重新填写"></td>
            </tr>
        </table>
    </form>
</center>
</body>
</html>
