<?php
session_start();
$link = mysqli_connect('localhost', 'root', '456789', 'bsglxt');//连接数据库
mysqli_query($link, 'set names utf8');
$id = $_SESSION['id'];
$name = $_POST['timu'];
$role = $_POST['role'];
$major = $_POST['major'];
$type = $_POST['type'];
$laiyuan = $_POST['laiyuan'];
$content = $_POST['shuoming'];
$suggest = $_POST['jianyi'];
$sql = "select num from t_teacher where teacher_id = $id";
$res = mysqli_query($link,$sql);
while($row = mysqli_fetch_array($res)){
	$num = $row['num'];
}
if ($num > 0) {
	$sql = "select * from t_subject where teacher_id = '$id' and name = '$name'";
	$res = mysqli_query($link,$sql);
	while(@$row = mysqli_fetch_array($res)){
		$ida = $row['teacher_id'];
		$namea = $row['name'];
	}
	if($id == $ida && $name == $namea){
		echo("<script>alert('您已上传过该题目');window.history.back(-1);</script>");
	}else{
		$sql = "insert into t_subject(subject_id,teacher_id,name,department,major,type,source,description,suggestion,state,choose) values('null','$id','$name','$role','$major','$type','$laiyuan','$content','$suggest','0','0')";
		mysqli_query($link,$sql);
		echo("<script>alert('上传成功，请等待审核');window.history.back(-1);</script>");
		$num = $num - 1;
		$sqlb = "update t_teacher set num = $num where teacher_id = $id";
		mysqli_query($link,$sqlb);
	}
	}else {
		echo("<script>alert('您最多只能上传五个题目');window.history.back(-1);</script>");
	}

mysqli_close($link);
?>