<?php

    $link = mysqli_connect('localhost', 'root', '456789', 'bsglxt');//连接数据库
    mysqli_query($link, 'set names utf8');
    $ida = $_POST['button'];
    $sql = "select * from t_student where student_id = '$ida'";
    $res = mysqli_query($link, $sql);
    while (@$row = mysqli_fetch_array($res)) {
        $name = $row['name'];
        $sex = $row['sex'];
        $class = $row['class'];
        $de = $row['department'];
        $ma = $row['major'];
        $phone = $row['phone'];
        $qq = $row['qq'];
        $email = $row['email'];
    } 
 ?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <title>个人信息</title>
    <style>
        #table{
            background-color: transparent;
            position: relative;
            top: 50px;
        }
        .d1{
            width: 80px;
        }
        .bianji{
        	position: relative;
        	top: 50px;
        	left: 590px;
        	text-decoration: none;
        }
    </style>
</head>
<body>
<center><h3>学生信息</h3></center>
<center>
    <table id="table" width="50%" border="1">
        <tr>
            <td class="d1">学号：</td>
            <td><center><?php echo $ida; ?></center></td>
        </tr>
        <tr>
        	<td class="d1">姓名：</td>
            <td><center><?php echo $name; ?></center></td>
    	</tr>
        <tr>
            <td class="d1">年龄：</td>
            <td><center><?php echo $sex; ?></center></td>
        </tr>
        <tr>
            <td class="d1">班级：</td>
            <td><center><?php echo $class; ?></center></td>
        </tr>
        <tr>
            <td class="d1">院系：</td>
            <td><center><?php echo $de; ?></center></td>
        </tr>
        <tr>
            <td class="d1">专业</td>：</td>
            <td><center><?php echo $ma; ?></center></td>
        </tr>
        <tr>
            <td class="d1">qq：</td>
            <td><center><?php echo $qq; ?></center></td>
        </tr>
        <tr>
            <td class="d1">联系电话：</td>
            <td><center><?php echo $phone; ?></center></td>
        </tr>
        <tr>
            <td class="d1">邮箱：</td>
            <td><center><?php echo $email; mysqli_close($link); ?></center></td>
        </tr>
    </table>
</center>
</body>
</html>