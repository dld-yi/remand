<?php 
session_start();
if ($_SESSION['name']  == null) {
	echo '<center><h3>请重新登录!</h3></center>';
	// require("../index.html");
	exit();
}
$link = mysqli_connect('localhost','root','456789','bsglxt');//连接数据库
mysqli_query($link,'set names utf8');
$id = $_SESSION['id'];
$sql = "select * from t_subject where teacher_id = $id";
$res = mysqli_query($link,$sql);
$num = mysqli_num_rows($res);
?>
<!doctype html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style type="text/css" media="all">
    * {
            margin: 0px;
            padding: 0px
        }
        table{
        	margin-top: 50px;
        	width: 80%;
        }
        input,button{
            background-color: transparent;
            color: #0000CC;
            margin: 0px;
            padding: 0px;
            outline: none;
            border-width: 0px;
            font-size: 100%;
            margin-top: 10px;
            margin-left: 5px;
        }
        td{
        	text-align: center;
        }
        a{
        	text-decoration: none;
        }
        p{
        	margin-top: 50px;
        }
    </style>
</head>
<body>
<center>
		<h2>已上传课题</h2>
		<table border="1"  cellspacing="0">
		
		<?php
			if($num == 0){
				echo("无上传题目");
			}else {
				echo "<tr><td>编号</td><td>题目</td><td>审核状态</td><td>修改</td><td>删除</td></tr>";
				while($row = mysqli_fetch_array($res)){
					$id = $row['subject_id'];
					$name = $row['name'];
					$state = $row['state'];
					if($state == 0){
						echo "<form action = '' method = 'post'><tr><td>$id</td><td>
						<button type='submit' name='button' formaction='check_subject_xiangxi.php' value='$id'>$name</button></td><td>待审核</td><td><button type='submit' name='button' formaction='check_subject_change.php' value='$id'>是</button></td><td><button type='submit' name='button' formaction='check_subject_delete.php' value='$id'>是</button></td></tr></form>";
					}elseif ($state == 1) {
						echo "<form action = '' method = 'post'><tr><td>$id</td><td>
						<button type='submit' name='button' formaction='check_subject_xiangxi.php' value='$id'>$name</button></td><td>审核已通过</td><td><button type='submit' name='button' formaction='check_subject_change.php' value='$id'>是</button></td><td>      </td></tr></form>";
					}else{
						echo "<form action = '' method = 'post'><tr><td>$id</td><td>
						<button type='submit' name='button' formaction='check_subject_xiangxi.php' value='$id'>$name</button></td><td>审核未通过</td><td><button type='submit' name='button' formaction='check_subject_change.php' value='$id'>是</button></td><td><button type='submit' name='button' formaction='check_subject_delete.php' value='$id'>是</button></td></tr></form>";
					}
				}
			}
			mysqli_close($link);
		?>
	</table>
</center>
</body>
</html>