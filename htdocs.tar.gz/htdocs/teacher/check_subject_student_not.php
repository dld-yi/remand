<?php
$link = mysqli_connect('localhost','root','456789','bsglxt');//连接数据库
mysqli_query($link,'set names utf8');
$id = $_POST['button'];
$sql = "update t_subject set choose = 0 where subject_id = '$id'";
mysqli_query($link,$sql);
$sql = "update t_student_subject set state = 2 where subject_id = '$id'";
$res = mysqli_query($link,$sql);
if (!$res) {
	echo("<script>alert('通过失败');window.history.back(-1);</script>");
}
echo("<script>alert('审核状态已提交');window.history.back(-1);</script>");
mysqli_close($link);
?>