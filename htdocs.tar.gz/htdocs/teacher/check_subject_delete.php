<?php
$link = mysqli_connect('localhost','root','456789','bsglxt');//连接数据库
mysqli_query($link,'set names utf8');
$id = $_POST['button'];
$sqla = "select * from t_subject where subject_id = $id";
$resa = mysqli_query($link,$sqla);
while($row = mysqli_fetch_array($resa)){
	$ida = $row['teacher_id'];
}
$sql = "update t_teacher set num = num +1 where teacher_id = $ida";
$res = mysqli_query($link,$sql);
$sql = "delete from t_subject where subject_id = $id ";
mysqli_query($link,$sql);
echo("<script>alert('删除成功');window.history.back(-1);</script>");
mysqli_close($link);