<?php
	$link = mysqli_connect('localhost', 'root', '456789', 'bsglxt');//连接数据库
	mysqli_query($link, 'set names utf8');
	$id = $_POST['button'];
	$ad = $_POST['zhidao'];
	$sql = "select * from t_score where student_id = '$id'";
	$res = mysqli_query($link,$sql);
	$num = mysqli_num_rows($res);
	if($num == 0){
		$sql = "insert into t_score values('$id','$ad','待录入','待录入','0')";
		mysqli_query($link,$sql);
		echo "<script>alert('录入成功');window.history.back(-1);</script>";
	}
	mysqli_close($link);