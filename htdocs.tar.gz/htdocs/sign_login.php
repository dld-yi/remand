<?php
$link = mysqli_connect('localhost','root','456789','bsglxt');//连接数据库
mysqli_query($link,'set names utf8');
$id = $_POST['zhanghao'];
$password = $_POST['mima'];
$repassword = $_POST['querenmima'];
$name = $_POST['xingming'];
$age = $_POST['nianling'];
$yx = $_POST['role'];
$class = $_POST['banji'];
$qq = $_POST['qq'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$sqli = "select student_id from t_student where student_id = '$id'";
$res = mysqli_query($link,$sqli);
$num = mysqli_num_rows($res);
if($num == 0){
	if ($password == $repassword) {
		$sql = "insert into t_student values('$id','$password','$name','$age','$class','$yx','$qq','$phone','$email')";
		if(mysqli_query($link,$sql)){
			echo("<script>alert('注册成功');</script>");
			echo("</br>");
			header("refresh:3;url=//www.dld-yi.top");
			print('请稍等...<br>三秒后自动跳转到登录页面~~~');
		}
		// code...
	} else {
			echo("<script>alert('两次密码不一致');window.history.back(-1);</script>");
	}
}else{
		echo("<script>alert('此账号已存在');window.history.back(-1);</script>");
}

?>