<?php
	$link = mysqli_connect('localhost','root','456789','bsglxt');//连接数据库
	mysqli_query($link,'set names utf8');
		session_start();
	$id = $_SESSION['id'];
	$sql = "select * from admins where id = '$id'";
	$res = mysqli_query($link,$sql);
	while($row = mysqli_fetch_array($res)){
		$name = $row['name'];
		$sex = $row['sex'];
		$phone = $row['phone'];
		$email = $row['email'];
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <style type="text/css" media="all">
    	a{
    		text-decoration: none;
    		color: blue;
    	}
    </style>
</head>
<body>
	<span>欢迎您！<?php echo $id; ?> 用户</span><a href="../logout.php">退出</a>
     <table border="0">
     	<tr>
     		<th>姓名</th>
     		<td> 
     			<?php echo $name; ?>
     		</td>
     	</tr>
     	<tr>
     		<th>性别</th>
     		<td><?php echo($sex); ?></td>
     	</tr>
     	<tr>
     		<th>电话</th>
     		<td><?php echo($phone); ?></td>
     	</tr>
     	<tr>
     		<th>邮箱</th>
     		<td><?php echo($email); ?></td>
     	</tr>
     </table>  
</body>
</html>