<?php
	$link = mysqli_connect('localhost','root','456789','bsglxt');//连接数据库
	mysqli_query($link,'set names utf8');
	session_start();
	$name = $_POST['userId'];
	$password = $_POST['passWord'];
	$sql = "select * from admins where id = '$name'";
	$res = mysqli_query($link,$sql);
	$num = mysqli_num_rows($res);
	if ($num != 0) {
		while($row = mysqli_fetch_array($res)){
			if($password == $row['password']){
				$_SESSION['id'] = $name;
				header("Location:path.php");
			}else{
				echo("<script>alert('密码错误！');window.history.back(-1);</script>");
			}
		}
	} else {
			echo("<script>alert('用户不存在！');window.history.back(-1);</script>");
	}
	mysqli_close($link);
?>