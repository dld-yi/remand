<?php
	$link = mysqli_connect('localhost','root','456789','bsglxt');//连接数据库
	mysqli_query($link,'set names utf8');

	$id = $_POST['id'];
	$password = $_POST['password'];
	$name = $_POST['name'];
	$sex = $_POST['sex'];
	$phone = $_POST['phone'];
	$email = $_POST['email'];
	$sql = "select id from where id = '$id'";
	$res = mysqli_query($link,$sql);
	if ($res) {
		echo("<script>alert('用户已存在！');window.history.back(-1);</script>");
	}else {
		$sql = "insert into admins values('$id','$password','$name','$sex','$phone','$email')";
		$res = mysqli_query($link,$sql);
		if($res){
			echo("<script>alert('注册成功');</script>");
			echo("</br>");
			header("refresh:3;url=login.html");
			print('请稍等...<br>三秒后自动跳转到登录页面~~~');
		}else{
			echo '注册失败，请重试！';
		}
	}
mysqli_close($link);
	
?>